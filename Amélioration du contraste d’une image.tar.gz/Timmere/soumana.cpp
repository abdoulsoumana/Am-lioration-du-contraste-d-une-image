#include "soumana.h"
#include "soumana.h"

soumana::soumana()
{

}
