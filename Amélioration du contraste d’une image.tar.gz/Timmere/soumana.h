#ifndef SOUMANA_H
#define SOUMANA_H


class soumana : public QQuickItem
{
    Q_OBJECT
public:
    soumana();

signals:

public slots:
};

#endif // SOUMANA_H